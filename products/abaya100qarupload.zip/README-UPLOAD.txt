ABAYA FOR 100 QAR — 4 NEW PRODUCTS
==================================

WHAT IS IN THIS ZIP
  products/abayablackpintuck100.jpg      -> Black Pintuck Beaded Abaya
  products/abayablackshawlcollar100.jpg  -> Black Beaded Shawl Collar Abaya
  products/abayablackcascade100.jpg      -> Black Beaded Cascade Open Abaya
  products/abayaemeraldbeaded100.jpg     -> Emerald Beaded Motif Open Abaya
  products.json                          -> full catalogue: your existing 18 + these 4 = 22

All 4 are Category "Luxury Abaya", Price 100 QAR.
Sizes 52 / 54 / 56 / 58 / 60 are built into the storefront and apply automatically.

HOW TO PUBLISH ON GITHUB
  1. Open your repository on github.com.
  2. Go into the "products" folder -> Add file -> Upload files.
     Drag in the 4 .jpg files from the products/ folder in this zip. Commit.
  3. Go back to the repository root, click products.json -> pencil (Edit).
  4. Select all the existing text, delete it, and paste in the contents of the
     products.json from this zip. Commit.
  5. Wait 1-2 minutes, then hard-refresh modestyandstyles.com (Ctrl+Shift+R).
     The 4 new abayas appear at the end of the ABAYA FOR 100 QAR showroom.

NOTES
  - Filenames must match exactly (all lowercase, no spaces).
  - Images were converted from PNG to JPG and compressed from ~2 MB to ~100 KB
    each so the showroom loads fast. Quality is unchanged on screen.
  - You sent 5 files but two were the same design (the black pintuck abaya),
    so it is listed once.
